arma::rowvec BS(double t, arma::vec knots);

